# Rab-Koach Security Solutions — Final Website Package

## Files Included
```
/
├── index.html          ← Homepage (hero, services, pricing, testimonials, blog, workshop)
├── services.html       ← Full services page with booking cards + quote form
├── about.html          ← Why Choose Us, mission statement, CEO bio (Jonathan's photo included)
├── contact.html        ← Contact form, info, FAQ
├── css/styles.css      ← All styles
├── js/main.js          ← Interactions (nav scroll, hamburger, animations, forms)
└── assets/images/
    ├── logo.png        ← Your logo (already placed)
    ├── ceo.jpg         ← Jonathan's photo (already placed)
    └── [add more]      ← See image list below
```

## Additional Images to Add (optional)
Place in `assets/images/` — site renders with gradient fallbacks if missing:

| Filename                    | Used In              |
|-----------------------------|----------------------|
| service-consultation.jpg    | Services page        |
| service-vulnerability.jpg   | Services page        |
| service-network.jpg         | Services page        |
| service-audit.jpg           | Services page        |
| service-forensics.jpg       | Services page        |
| service-training.jpg        | Services page        |
| why-hero.jpg                | Why Choose Us page   |
| blog-1.jpg                  | Homepage blog        |
| blog-2.jpg                  | Homepage blog        |
| blog-3.jpg                  | Homepage blog        |

## Deploy to Linux Server (Apache / Nginx)

### Apache
```bash
cp -r rab-koach-final/* /var/www/html/
```

### Nginx config
```nginx
server {
    listen 80;
    server_name rabkoachsecuritysolutions.com www.rabkoachsecuritysolutions.com;
    root /var/www/html;
    index index.html;
    location / { try_files $uri $uri/ =404; }
    gzip on;
    gzip_types text/css application/javascript text/html;
}
```

### Free SSL (Certbot)
```bash
sudo certbot --nginx -d rabkoachsecuritysolutions.com -d www.rabkoachsecuritysolutions.com
```

## To Make Forms Send Email
Replace the JS form handler in `js/main.js` with Formspree:
```html
<form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
```
Or use EmailJS / a PHP mailer script.

## Colors (CSS Variables in styles.css)
- `--royal: #1246B5` — primary blue
- `--ice: #5BC8F5` — accent cyan
- `--gold: #E8B84B` — gold accents
