/* =========================================================
   RAB-KOACH SECURITY SOLUTIONS — main.js
   ========================================================= */
document.addEventListener('DOMContentLoaded', () => {

  /* ── NAVBAR SCROLL ───────────────────────────────────────── */
  const nav = document.querySelector('.nav');
  const onScroll = () => nav?.classList.toggle('stuck', window.scrollY > 30);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ── ACTIVE LINK ─────────────────────────────────────────── */
  const page = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav__links a, .mob-nav a').forEach(a => {
    if (a.getAttribute('href') === page) a.classList.add('active');
  });

  /* ── HAMBURGER ───────────────────────────────────────────── */
  const burger = document.querySelector('.burger');
  const mob    = document.querySelector('.mob-nav');
  burger?.addEventListener('click', () => {
    burger.classList.toggle('open');
    mob?.classList.toggle('open');
    document.body.style.overflow = mob?.classList.contains('open') ? 'hidden' : '';
  });
  mob?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    burger?.classList.remove('open');
    mob.classList.remove('open');
    document.body.style.overflow = '';
  }));

  /* ── SCROLL REVEAL ───────────────────────────────────────── */
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -36px 0px' });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));

  /* ── COUNTER ANIMATE ─────────────────────────────────────── */
  const cio = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el = e.target;
      const target = +el.dataset.count;
      const suffix = el.dataset.suffix || '';
      let cur = 0;
      const step = target / (1800 / 16);
      const tick = () => {
        cur = Math.min(cur + step, target);
        el.textContent = Math.floor(cur) + suffix;
        if (cur < target) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      cio.unobserve(el);
    });
  }, { threshold: 0.5 });
  document.querySelectorAll('[data-count]').forEach(el => cio.observe(el));

  /* ── FORM SUBMIT ─────────────────────────────────────────── */
  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const btn = form.querySelector('.btn-primary');
      if (!btn) return;
      const orig = btn.innerHTML;
      btn.innerHTML = `<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg> Message Sent!`;
      btn.disabled = true;
      btn.style.background = 'linear-gradient(135deg,#0a7a5a,#0d9e70)';
      btn.style.boxShadow = '0 4px 20px rgba(13,158,112,.4)';
      setTimeout(() => {
        btn.innerHTML = orig;
        btn.disabled = false;
        btn.style.background = '';
        btn.style.boxShadow = '';
        form.reset();
      }, 3500);
    });
  });

});
